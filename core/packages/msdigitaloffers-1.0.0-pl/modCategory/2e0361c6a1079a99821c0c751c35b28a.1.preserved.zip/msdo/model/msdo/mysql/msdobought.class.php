<?php
require_once (dirname(dirname(__FILE__)) . '/msdobought.class.php');
class msdoBought_mysql extends msdoBought {}