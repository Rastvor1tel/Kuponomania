<?php
class msdoOffer extends xPDOSimpleObject {}