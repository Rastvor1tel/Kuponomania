<?php
class msdoBought extends xPDOSimpleObject {}