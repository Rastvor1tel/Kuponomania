<?php

$_lang['area_msdo_main'] = 'Main';

$_lang['setting_msdo_active'] = 'Active / Inactive';

$_lang['setting_msdo_allow_zero_price'] = 'Allow zero price';

$_lang['setting_msdo_frontend_js'] = 'Frontend javascript';

$_lang['setting_msdo_frontend_css'] = 'Frontend css';
