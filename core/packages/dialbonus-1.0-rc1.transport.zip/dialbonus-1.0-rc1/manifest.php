<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '',
    'changelog' => '',
    'setup-options' => 'dialbonus-1.0-rc1/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '10a5f148917bab4498fda66eaca274de',
      'native_key' => 'dialbonus',
      'filename' => 'modNamespace/b528deed8fe06c3a6e284a6112d3bca0.vehicle',
      'namespace' => 'dialbonus',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c4beb68e1658623b271cffb2d312cc25',
      'native_key' => 1,
      'filename' => 'modCategory/70e294a43306eac56ce2a77ac4fa435d.vehicle',
      'namespace' => 'dialbonus',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'fb6ce177f0a30c93cbf7f731a91b1d53',
      'native_key' => 'dialbonus',
      'filename' => 'modMenu/69ccbfef751e5decc2008339798a7994.vehicle',
      'namespace' => 'dialbonus',
    ),
  ),
);