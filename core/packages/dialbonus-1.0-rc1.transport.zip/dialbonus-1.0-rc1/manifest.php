<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '',
    'changelog' => '',
    'setup-options' => 'dialbonus-1.0-rc1/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '77619d9ca16d8f68c43563632e95b076',
      'native_key' => 'dialbonus',
      'filename' => 'modNamespace/d6ccbda8bbae61004e128dcd361142b9.vehicle',
      'namespace' => 'dialbonus',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '78354fe398f0222844b756ed8a418068',
      'native_key' => 1,
      'filename' => 'modCategory/acfbc1b55f6342e2928fca5618c54bb9.vehicle',
      'namespace' => 'dialbonus',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a2c817d74876f2cbcbaf985f45bf296f',
      'native_key' => 'dialbonus',
      'filename' => 'modMenu/fc98f0fed4b095273a7d560007225af8.vehicle',
      'namespace' => 'dialbonus',
    ),
  ),
);