<?php
require_once (dirname(__DIR__) . '/msorderaddress.class.php');
class msOrderAddress_mysql extends msOrderAddress {}