<?php
require_once (dirname(__DIR__) . '/mscategorymember.class.php');
class msCategoryMember_mysql extends msCategoryMember {}