<?php
require_once (dirname(__DIR__) . '/mscategory.class.php');
class msCategory_mysql extends msCategory {}