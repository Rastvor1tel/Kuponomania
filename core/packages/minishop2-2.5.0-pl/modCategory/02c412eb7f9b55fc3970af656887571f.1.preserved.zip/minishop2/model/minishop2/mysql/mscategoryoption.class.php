<?php
require_once (dirname(__DIR__) . '/mscategoryoption.class.php');
class msCategoryOption_mysql extends msCategoryOption {}