<?php
require_once (dirname(__DIR__) . '/msproductfile.class.php');
class msProductFile_mysql extends msProductFile {}