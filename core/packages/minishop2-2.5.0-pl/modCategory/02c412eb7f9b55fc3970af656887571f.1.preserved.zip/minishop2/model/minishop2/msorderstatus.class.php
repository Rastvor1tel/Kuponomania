<?php

/**
 * @property int id
 * @property int rank
 */
class msOrderStatus extends xPDOSimpleObject {}