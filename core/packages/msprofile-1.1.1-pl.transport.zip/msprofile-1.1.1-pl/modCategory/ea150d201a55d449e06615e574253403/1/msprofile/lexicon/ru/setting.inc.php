<?php

$_lang['area_msprofile_main'] = 'Основные';