--------------------
msProfile
--------------------
Author: Naumkin Vasily <bezumkin@yandex.ru>
--------------------

Component for miniShop2 that adds to the displaying of user profiles and a new method of payment - internal account of the buyer.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/bezumkin/msProfile/issues