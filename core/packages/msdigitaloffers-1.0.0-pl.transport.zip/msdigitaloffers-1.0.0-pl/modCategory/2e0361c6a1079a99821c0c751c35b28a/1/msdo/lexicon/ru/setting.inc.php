<?php

$_lang['area_msdo_main'] = 'Основные';

$_lang['setting_msdo_active'] = 'Включено';
$_lang['setting_msdo_active_desc'] = 'Включить / Выключить цифровые предложения в Minishop2.';

$_lang['setting_msdo_type'] = 'Логика работы';
$_lang['setting_msdo_type_desc'] = '1. Цифровые коды <br>2. Файлы';

