<?php
include_once 'setting.inc.php';

$_lang['msdo'] = 'msDigitalOffers';
$_lang['msdo_menu_desc'] = 'Дополнительные цены - настройки.';

$_lang['msdo_settings'] = 'Настройки';

$_lang['msdo_setting_option'] = 'Опции';
$_lang['msdo_setting_option_intro'] = 'Панель управления опциями продукта.';

$_lang['msdo_setting_operation'] = 'Операции';
$_lang['msdo_setting_operation_intro'] = 'Панель управления операциями над ценами.';