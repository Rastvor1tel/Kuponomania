<?php
require_once (dirname(dirname(__FILE__)) . '/msdooffer.class.php');
class msdoOffer_mysql extends msdoOffer {}