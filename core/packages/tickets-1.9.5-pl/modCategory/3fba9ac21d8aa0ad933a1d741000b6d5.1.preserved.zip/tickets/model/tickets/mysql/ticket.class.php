<?php
require_once (dirname(__DIR__) . '/ticket.class.php');
class Ticket_mysql extends Ticket {}